#Terraform Application Load Balancer
	  1) Created keypair with name: terraform-demo in AWS account.
	  2) Created IAM User: terraform-user in AWS account.
	  3) Created S3 bucket with name: "10-cloud-terraform-remote-state-storage-s3" to store backend file in s3 bucket.
	  3) "install python" in your local machine.
	  4) "pip install awscli" in your local machine.
      5) setup "aws configure" in your local machine.
	  6) In Certificate Manager, AWS SSL is configured in AWS account.
	  7) Terraform Task Setup Infrastructure with below items:
	      7.1) VPC
		  7.2) 2-Public Subnets, 2-Private Subnets
		  7.3) 1-Internet Gateway
		  7.4) 2-Elastic IP Address
		  7.5) 2-NAT Gateways
		  7.6) Public Security and Private Security Group
		  7.7) 2-Public Instances
		  7.8) 2-Private Instances
		  7.9) RDS-Mysql
		  7.10) Load Balancer - 1-Application Load Balancers with 2 target groups
		  7.11) In Route53, application load balancer url is added.
      8) Run terraform with below commands:
	       terraform init
	       terraform plan -var-file="QA.tfvars"
	       terraform apply -var-file="QA.tfvars"
	     
		 terraform destroy -var-file="QA.tfvars"


